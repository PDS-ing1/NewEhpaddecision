package fr.esipe.pds.ehpaddecision.frontend;

public class Smoke_Sensors {

}
